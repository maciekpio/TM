# B6. Other Advanced Parsers

- [`Bounded`] (build with [`rule#refine`] and [`BoundedParserBuilder`])

<!-- TODO: ensure that all built-in parsers have indeed been documented -->

[`Bounded`]: https://javadoc.io/doc/com.norswap/autumn/latest/norswap/autumn/parsers/Bounded.html
[`rule#refine`]: https://javadoc.io/doc/com.norswap/autumn/latest/norswap/autumn/Grammar.rule.html#refine-java.lang.Object-
[`BoundedParserBuilder`]: https://javadoc.io/doc/com.norswap/autumn/latest/norswap/autumn/parsers/Grammar.BoundedParserBuilder.html