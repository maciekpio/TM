package norswap.lang.java.ast;

public enum BasicType
{
    _byte,
    _short,
    _int,
    _long,
    _char,
    _float,
    _double,
    _boolean,
    _void
}
