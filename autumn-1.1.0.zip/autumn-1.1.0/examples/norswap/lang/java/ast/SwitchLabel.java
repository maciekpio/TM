package norswap.lang.java.ast;

public interface SwitchLabel {
}
