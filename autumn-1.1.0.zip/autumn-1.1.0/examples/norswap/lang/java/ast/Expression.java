package norswap.lang.java.ast;

public interface Expression extends Statement, AnnotationElement {
}
