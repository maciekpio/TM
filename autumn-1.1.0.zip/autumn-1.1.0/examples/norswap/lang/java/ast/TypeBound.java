package norswap.lang.java.ast;

public interface TypeBound
{
    /** The bounding type. */
    TType type();
}
