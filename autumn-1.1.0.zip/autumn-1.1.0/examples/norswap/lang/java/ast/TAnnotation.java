package norswap.lang.java.ast;

public interface TAnnotation extends AnnotationElement, Modifier {
}
