package norswap.lang.java.ast;

public interface Declaration extends Statement {
}
