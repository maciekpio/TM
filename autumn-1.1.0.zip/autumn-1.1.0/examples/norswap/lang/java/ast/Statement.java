package norswap.lang.java.ast;

public interface Statement {
}
